"""Unit test package for mcmc_statphys."""
