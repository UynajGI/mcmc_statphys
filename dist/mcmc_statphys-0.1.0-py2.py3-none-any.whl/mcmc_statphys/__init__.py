"""Top-level package for mcmc-statphys."""

__author__ = """Uynaj GI"""
__email__ = 'suquan12148@outlook.com'
__version__ = '0.1.0'
