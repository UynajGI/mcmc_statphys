=====
Usage
=====

To use mcmc-statphys in a project::

    import mcmc_statphys
