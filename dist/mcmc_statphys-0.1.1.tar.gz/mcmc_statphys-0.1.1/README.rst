=============
mcmc-statphys
=============


.. image:: https://img.shields.io/pypi/v/mcmc_statphys.svg
        :target: https://pypi.python.org/pypi/mcmc_statphys

.. image:: https://img.shields.io/travis/uynajgi/mcmc_statphys.svg
        :target: https://travis-ci.com/uynajgi/mcmc_statphys

.. image:: https://readthedocs.org/projects/mcmc-statphys/badge/?version=latest
        :target: https://mcmc-statphys.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status




A library project of Monte Carlo simulation algorithms for some statistical physics models (in particular, the Ising model and its variants).


* Free software: MIT license
* Documentation: https://mcmc-statphys.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
