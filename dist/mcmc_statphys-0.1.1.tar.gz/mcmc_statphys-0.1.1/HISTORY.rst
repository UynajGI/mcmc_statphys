=======
History
=======

0.1.1 (2023-05-14)
------------------

* Replace mcmc_statphys

0.1.0 (2023-05-14)
------------------

* Implement mcmc_statphys
* Implement model
* Implement sample
